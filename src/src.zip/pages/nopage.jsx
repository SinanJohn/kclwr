export default function NoPage() {
    return (
        <></>
    )
}